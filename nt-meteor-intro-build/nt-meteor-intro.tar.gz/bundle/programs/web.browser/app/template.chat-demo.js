(function(){
Template.body.addContent((function() {
  var view = this;
  return HTML.DIV({
    "class": "container"
  }, "\n    ", HTML.HEADER("\n        ", HTML.Raw("<h1>Nagpur Techies Chat App</h1>"), "\n        ", Spacebars.include(view.lookupTemplate("loginButtons")), "\n    "), "\n    ", HTML.UL("\n        ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("recentMessages"));
  }, function() {
    return [ "\n        ", HTML.LI("\n            ", HTML.DIV({
      "class": "username"
    }, Blaze.View("lookup:username", function() {
      return Spacebars.mustache(view.lookup("username"));
    })), "\n            ", HTML.DIV({
      "class": "message"
    }, Blaze.View("lookup:text", function() {
      return Spacebars.mustache(view.lookup("text"));
    })), "\n        "), "\n        " ];
  }), "\n    "), "\n    ", HTML.FOOTER("\n        ", Blaze.If(function() {
    return Spacebars.call(view.lookup("currentUser"));
  }, function() {
    return [ "\n        ", HTML.FORM({
      "class": "new-message"
    }, "\n            ", HTML.INPUT({
      type: "text",
      name: "text",
      placeholder: "Add a message"
    }), "\n        "), "\n        " ];
  }), "\n    "), "\n");
}));
Meteor.startup(Template.body.renderToDocument);

}).call(this);
